package com.oliviabecht.notesapplicationobecht;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

//Since all member variables are Strings they are already Serializable (android knows how to send them by default)
//so we don't have to do anything else here
//If you have a custom class object in this class that is not Serializable by default then we would have to
//write some more code
public class Note implements Serializable {

    private final String TAG = "Note";

    private static final String NOTE_TITLE = "title";
    private static final String NOTE_DATE = "date";
    private static final String TEXT = "text";

    private String title;
    private String text;
    private String date; //should this be a Date?

    public Note(String title, String text, String date) {
        this.title = title;
        this.text = text;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public JSONObject toJSON(){
        JSONObject out = new JSONObject();
        try {
            out.put(NOTE_TITLE, title);
            out.put(NOTE_DATE, date);
            out.put(TEXT, text);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return out;
    }

    //add a constructor that can take in a json object
    public Note(JSONObject in){
        try {
            title = in.getString(NOTE_TITLE);
            Log.d("Note", "title:" + title);
            date = in.getString(NOTE_DATE);
            text = in.getString(TEXT);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}
