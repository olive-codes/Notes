package com.oliviabecht.notesapplicationobecht;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class MainActivity extends AppCompatActivity {
    //Rec View to Display notes
    private RecyclerView recNotes;

    //Array List to hold notes in
    ArrayList<Note> allNotes = new ArrayList<>();
    //File to save notes to
    public static final String FILENAME = "notes.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //About Page Button Link to About Page
        ImageButton aboutPageButton = (ImageButton) findViewById(R.id.aboutPageButton);
        aboutPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
            }
        });

        //Edit Note Button Link to Edit Note Page
        ImageButton editPageButton = (ImageButton) findViewById(R.id.editNoteButton);
        editPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editIntent = new Intent(MainActivity.this, EditActivity.class);
                editIntent.putExtra("existingNotes", allNotes);
                startActivity(editIntent);
            }
        });

        //Here below need to refine has to do with Rec View/ JSON, saving and displaying notes
        recNotes = findViewById(R.id.recNotes);


        //make the adapter
        TextView mainActTitle = (TextView) findViewById(R.id.mainActTitle);
        readNotesFromFile();
        allNotes.sort((note, nextNote) -> {

            SimpleDateFormat sdformat = new SimpleDateFormat("EEE MMM d, h:mm a");
            Date d1 = null;
            Date d2 = null;
            try {
                d1 = sdformat.parse(note.getDate());
                d2 = sdformat.parse(nextNote.getDate());

            } catch (ParseException e) {
                e.printStackTrace();
            }

            return d2.compareTo(d1);


        });
        updateNotesCount();
        Adapter adpNotes = new Adapter(allNotes, mainActTitle);
        //set the recyclerview to use that adapter
        recNotes.setAdapter(adpNotes);
        //This recycler view DOES NOT KNOW how to show it's items
        //we need to set a layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        //assign the rec view the vertical layout
        recNotes.setLayoutManager(layoutManager);


    }



    //Update Title on Main Page with number of notes
    private void updateNotesCount() {
        String Title = "Android Notes (" + allNotes.size() + ")";
        TextView tv1 = (TextView) findViewById(R.id.mainActTitle);
        tv1.setText(Title);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateNotesCount();
    }

    //Outside of OnCreate

    void readNotesFromFile() {

        try {
            File file = new File(getApplicationContext().getFilesDir(), FILENAME);

            // Note:  Double backquote is to avoid compiler
            // interpret words
            // like \test as \t (ie. as a escape sequence)

            // Creating an object of BufferedReader class
            BufferedReader br = new BufferedReader(new FileReader(file));
            String curLine;
            StringBuilder fileContents = new StringBuilder();
            // Condition holds true till
            // there is character in a string
            while ((curLine = br.readLine()) != null) {
                fileContents.append(curLine);
            }

            String jsonFileContents = fileContents.toString();
            //JSONArray object can create an object from a json formatted string
            JSONArray fileJSONArray = new JSONArray(jsonFileContents);
            //go through the json array and for each json object turn it into a note object

            for(int i = 0; i < fileJSONArray.length(); i++) {
                JSONObject curNoteObj = fileJSONArray.getJSONObject(i);
                Note newNote = new Note(curNoteObj);
                allNotes.add(newNote);
            }

        } catch (FileNotFoundException e) {
            //e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            Log.d("DEBUG", "Error: the JSON string in file was incorrect format");
            e.printStackTrace();
        }


    }
}