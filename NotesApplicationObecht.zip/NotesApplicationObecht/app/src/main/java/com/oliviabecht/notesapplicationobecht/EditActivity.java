package com.oliviabecht.notesapplicationobecht;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditActivity extends AppCompatActivity {

    private final String TAG = "EditActivity";

    private EditText title, text;

    //private TextView dateTimeDisplay;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;
    private ArrayList<Note> existingNotes;

    /**
     * Populate note data if it is passed for editing
     */
    private void loadNoteForEditing() {
        Note note = (Note) getIntent().getExtras().getSerializable("note");
        if (note != null) {
            title.setText(note.getTitle());
            text.setText(note.getText());
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_note);

        title = findViewById(R.id.editTitleNote);
        text = findViewById(R.id.editTextNote);
        existingNotes = (ArrayList<Note>) getIntent().getExtras().getSerializable("existingNotes");

        loadNoteForEditing();

        //Save Page Button to save to json
        ImageButton savePageButton = (ImageButton) findViewById(R.id.editSaveButton);
        savePageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Save Note to Json and go back to main page

                calendar = Calendar.getInstance();

                dateFormat = new SimpleDateFormat("EEE MMM d, h:mm a");
                date = dateFormat.format(calendar.getTime());
                Log.d(TAG, "getNote: date is" + date);

                String noteTitle = title.getText().toString();
                Log.d(TAG, "getNote: title is" + noteTitle);
                if (noteTitle.trim().isEmpty()) {
                    //TODO add validation if blank to not save it
                    Log.d(TAG, "getNote: title Empty");
                }

                String noteText = text.getText().toString();
                Log.d(TAG, "getNote: text is" + noteText);
                if (noteText.trim().isEmpty()) {
                    //TODO add validation if blank to not save it
                    Log.d(TAG, "getNote: text Empty");
                }

                Note note = new Note(noteTitle, noteText, date);

                if (noteTitle.isEmpty()) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);
                    builder.setTitle("Your note will not be saved!");
                    //change to title of note
                    builder.setMessage("Select Cancel to add title or select Ok");

                    builder.setCancelable(false);

                    builder.setPositiveButton("Cancel", (DialogInterface.OnClickListener) (dialog, which) -> {
                        //Stay in edit activity
                    });

                    builder.setNegativeButton("Ok", (DialogInterface.OnClickListener) (dialog, which) -> {
                        //do not save!
                        startActivity(new Intent(EditActivity.this, MainActivity.class));
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }
                else {
                    updateNotes(note);
                    startActivity(new Intent(EditActivity.this, MainActivity.class));
                }
            }
        });

        //onBackPressed();
        // Code Outside Of Save Button Starts here for about page
    }


    /**
     * Updates the notes and checks if editing or creating.
     * Then it handles the correct action based on if a note is passed in or not
     * @param note
     */
    private void updateNotes(Note note) {

        boolean isEditing = getIntent().getExtras().getSerializable("note") != null;
        if(isEditing) {
            editNote(getIntent().getExtras().getInt("positionOfNote"));
        }
        else {
            saveNotesToFile(note);
        }
    }

    /**
     * Edit Note
     */
    private void editNote(int positionOfNote) {
        try {
            File file = new File(getApplicationContext().getFilesDir(), MainActivity.FILENAME);
            //check to see if this file exists
            if (!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos = openFileOutput(MainActivity.FILENAME, Context.MODE_PRIVATE);

            JSONArray notesJSONArray = new JSONArray();

            // set date of edited note
            calendar = Calendar.getInstance();
            dateFormat = new SimpleDateFormat("EEE MMM d, h:mm a");
            date = dateFormat.format(calendar.getTime());

            for(int i = 0; i < existingNotes.size(); i++) {
                // if position matches, overwrite that note with the edited data
                if(i == positionOfNote) {
                    existingNotes.get(i).setTitle(title.getText().toString());
                    existingNotes.get(i).setText(text.getText().toString());
                    existingNotes.get(i).setDate(date);

                }
                JSONObject newNoteObj = new JSONObject();
                newNoteObj.put("title", existingNotes.get(i).getTitle());
                newNoteObj.put("text", existingNotes.get(i).getText());
                newNoteObj.put("date", existingNotes.get(i).getDate());
                notesJSONArray.put(newNoteObj);
            }

            fos.write(notesJSONArray.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            Log.d("Write ERROR", "Error: could not write to note file");
            e.printStackTrace();
        }
        Log.d("Write Success", "good");
    }

    /**
     * Save to the notes.json file my new note
     */
    private void saveNotesToFile(Note newNote){
        try {
            File file = new File(getApplicationContext().getFilesDir(), MainActivity.FILENAME);
            //check to see if this file exists
            String filesDir = getApplicationContext().getFilesDir().getAbsolutePath();
            if (!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos = openFileOutput(MainActivity.FILENAME, Context.MODE_PRIVATE);

            JSONArray notesJSONArray = new JSONArray();

            for(int i = 0; i < existingNotes.size(); i++) {
                JSONObject newNoteObj = new JSONObject();
                newNoteObj.put("title", existingNotes.get(i).getTitle());
                newNoteObj.put("text", existingNotes.get(i).getText());
                newNoteObj.put("date", existingNotes.get(i).getDate());
                notesJSONArray.put(newNoteObj);
            }
            // add current note to array
            JSONObject newNoteObj = new JSONObject();
            newNoteObj.put("title", newNote.getTitle());
            newNoteObj.put("text", newNote.getText());
            newNoteObj.put("date", newNote.getDate());
            notesJSONArray.put(newNoteObj);

            Log.d("mainActivity", "jsonStr: " + newNoteObj);

            fos.write(notesJSONArray.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            Log.d("Write ERROR", "Error: could not write to note file");
            e.printStackTrace();
        }
        Log.d("Write Success", "good");
    }

//OUTSIDE OF ONCREATE


    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }


    //When the user presses the back button...

    public void onBackPressed() {

        if (title.getText().toString().isEmpty()) {
            startActivity(new Intent(EditActivity.this, MainActivity.class));
        }
        else {

            AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);
            builder.setTitle("Your note is not saved!");
            //change to title of note
            builder.setMessage("Save note '" + title.getText().toString() + "'?");

            builder.setCancelable(false);

            builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {

                // Need to save to Json first!!!!
                calendar = Calendar.getInstance();

                dateFormat = new SimpleDateFormat("EEE MMM d, h:mm a");
                date = dateFormat.format(calendar.getTime());
                Log.d(TAG, "getNote: date is" + date);

                String noteTitle = title.getText().toString();
                Log.d(TAG, "getNote: title is" + noteTitle);
                if (noteTitle.trim().isEmpty()) {
                    //TODO add validation if blank to not save it
                    Log.d(TAG, "getNote: title Empty");
                }

                String noteText = text.getText().toString();
                Log.d(TAG, "getNote: text is" + noteText);
                if (noteText.trim().isEmpty()) {
                    //TODO add validation if blank to not save it
                    Log.d(TAG, "getNote: text Empty");
                }

                Note note = new Note(noteTitle, noteText, date);
                updateNotes(note);


                startActivity(new Intent(EditActivity.this, MainActivity.class));
            });

            builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
                //do not save!
                startActivity(new Intent(EditActivity.this, MainActivity.class));
            });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    //End of back Button
}
