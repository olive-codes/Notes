package com.oliviabecht.notesapplicationobecht;

import java.lang.reflect.Field;

public class FileResource {

    public void readFiles(){

    }
}
